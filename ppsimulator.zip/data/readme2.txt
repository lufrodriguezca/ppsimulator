######################################################
# This example demonstrates host-parasite model
#  - there are two species types: host (1) and parasite (2)
#  - there are four processes: 1) reproduction of host, 2) density-dependent death of host, 3) infection (parasite infects host), and 4) density-independent death of parasite
######################################################

R
source("rfunctions.r")
set.seed(1)
x1=initialize(species=1,density.per.area=1,U=50,dim=2)
x2=initialize(species=2,density.per.area=.01,U=50,dim=2)
x=rbind(x1,x2)
write.file(x,"in2")

cmd="../ppsimulator -p processes.txt -m model2.txt -i in2 -o out2 -U 50 -T 30 -dT .1 -H 1"
system(cmd)

a=read.timeseries.file("out2.points")

first=get.point.coordinates(a,ind=1,dim=2)
plot.points(first$coord, first$species, U=50, main="Initial",scol=c("blue","red"))

last=get.point.coordinates(a,ind=length(a),dim=2)
plot.points(last$coord, last$species, U=50, main="Final",scol=c("blue","red"))

movie(a,U=50,pause.interval=.1, scex=c(1,1), spch=c(19,19),scol=c("blue","red"))

n=read.table("out2.counts",header=T)
plot.species.density(n,U=50,dim=2)

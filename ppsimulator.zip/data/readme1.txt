#############################################################################
# This example demonstrates Spatial and Stochastic Logistic Model (SSLM)
#  - there is only one species type (1)
#  - there are three processes: 1) reproduction, 2) density-independent death, and 3) density-dependent death
##############################################################################

R
source("rfunctions.r")
set.seed(1)
x=initialize(species=1,density.per.area=1,U=50,dim=2)
write.file(x,"in1")

cmd="../ppsimulator -p processes.txt -m model1.txt -i in1 -o out1 -U 50 -T 30 -dT .1 -H 1"
system(cmd)

a=read.timeseries.file("out1.points")

first=get.point.coordinates(a,ind=1,dim=2)
plot.points(first$coord, first$species, U=50, main="Initial")

last=get.point.coordinates(a,ind=length(a),dim=2)
plot.points(last$coord, last$species, U=50, main="Final")

movie(a,U=50,pause.interval=.1, scex=1, spch=19,scol="blue")

n=read.table("out1.counts",header=T)
plot.species.density(n,U=50,dim=2)
